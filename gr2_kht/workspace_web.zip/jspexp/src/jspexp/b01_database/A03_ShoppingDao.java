package jspexp.b01_database;


/*
DAO(Database Access object)
	1.온라인 쇼핑몰 상품 정보 리스트 처리 과정
		1) 상품 정보
			상품 key, 종류, 물건명, 단가, 재고수량
	2. 개발 순서
		1) 테이블 생성
		2) 물건 key를 위한 sequence 생성
		3) SQL 만들기
		4) SQL에 따른 VO 생성
		5) DB DAO 생성
			1) 전역 field 객체 선언 (Connection, Statement, ResultSet)
			2) 연결 공통 메서드 선언
			3) 조회하는 ArrayList<VO> 메서드 선언
				- 연결메서드 호출 (예외처리)
				- Statement로 SQL 대화 처리
				- SQL 대화의 결과로 ResultSet 받기
				- while()을 활용하여 ArrayList<VO>에 담기와 return
				- 자원(객체메모리)의 해제
				 	rs.close(), stmt,close(), conn,close();
		6) 웹 화면 구현
			- import, 객체 DAO 생성
			- table에 for문으로 list 처리
 */


import java.sql.*;
import java.util.ArrayList;
import jspexp.z01_vo.P4MEMBER;
import jspexp.z01_vo.Product;

public class A03_ShoppingDao {
	
	private Connection con;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
public void setCon() throws SQLException{
	

	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	String info = "jdbc:oracle:thin:@192.168.4.90:1521:xe";
	con = DriverManager.getConnection(info, "scott", "tiger");


}

	public ArrayList<Product> getProductList(){
		ArrayList<Product> productList = new ArrayList<Product>();
		
		try {
			setCon();
			String sql = "SELECT * FROM PRODUCT";
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			Product products = null;
			
			while(rs.next()) {
				
				
				
				products = new Product();
				products.setSno(rs.getInt("sno"));
				products.setKind(rs.getString("kind"));
				products.setName(rs.getString("name"));
				products.setPrice(rs.getInt("price"));
				products.setCnt(rs.getInt("cnt"));
				
				productList.add(products);
				
				/*
				products.add(new Product(rs.getInt("sno"),
										rs.getString("kind"),
										rs.getString("name"),
										rs.getInt("price"),
										rs.getInt("cnt"))
				 */
				
				
			}
			
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return productList;
	}

/*

#PreparedStatement 객체 활용
	1. 목적
		1) 보안상 : sql injection 방지
			SQL을 동적인 문자열 조합에 의해 만들었을 때, sql script를 통해
			% 또는 만들어지는 script를 입력하면 보안상에 문제가 발생
			
			SELECT * FROM MEMBER
			WHERE id = 'himan' pass = 7777
			=> sql을 동적으로 변경시켜 처리하면 모든 계정과 데이터가 노출될 수 있음
			pass의 내용에 pass:[888 or 1=1]
			where id = 'himan' pass= 888 or 1=1 ===> 무조건 로그인
		2) 속도 개선
			- db 서버 sql 컴파일 실행
				새로운 sql이 실행될 때, 동일한 sql은 기존 컴파일된 내용을 실행
			- SELECT * FROm MEMBER WHERE ID = 'himan' pass=7777
				동적 query는 id, pass 바뀔 때 마다 재컴파일
			
				PreparedStatment는
				SELECT * FROM MEMBER WHERE ID = ? PASS = ?
				동일한 sql로 인식
				param으로 컴파일하므로, 데이터 전달 속도 개선 효과가 생김

	2. PreparedStatement의 활용
		1) SQL에 변경될 데이터를 ?로 처리
		2) Statement ==? PreparedStatement로 처리
		3) ?의 갯수만큼 해당 내용에 들어갈 데이터
			pstmt.setXXX(?순위 index, 들어갈 데이터)

 */
	
	public ArrayList<Product> plist(Product sch){
		ArrayList<Product> plist = new ArrayList<Product>();
		try {
			setCon();
			String sql = "SELECT * FROM PRODUCT\r\n" + 
						"WHERE 1=1\r\n" +  
						"AND name LIKE '%'||?||'%'\r\n" +
						"AND price BETWEEN ? AND ? " + 
						"ORDER BY NAME DESC ";
			
			
			
			// stmt = con.createStatement();
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, sch.getName());
			pstmt.setInt(2, sch.getFrPrice());
			pstmt.setInt(3, sch.getToPrice());
			
			System.out.println(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				plist.add(new Product(rs.getInt(1),
									rs.getString(2),
									rs.getString(3),
									rs.getInt(4),
									rs.getInt(5))
						);
			}
			
			rs.close();
			pstmt.close();
			con.close();
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return plist;
	}


public static void main(String[] args) {
		// TODO Auto-generated method stub
		A03_ShoppingDao dao = new A03_ShoppingDao();
		System.out.println(dao.getProductList().size());
		
		Product sch = new Product(2000,4000,"바나나");
		for(Product p:dao.getProductList()) {
			System.out.print(p.getSno()+"\t");
			System.out.print(p.getKind()+"\t");
			System.out.print(p.getName()+"\t");
			System.out.print(p.getPrice()+"\t");
			System.out.print(p.getCnt()+"\n");
		}
	}

}
