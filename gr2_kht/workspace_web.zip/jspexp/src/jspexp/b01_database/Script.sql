SELECT * FROM P4MEMBER;


SELECT * FROM emp
WHERE 1=1
AND ename LIKE '%'||'A'||'%'
AND job LIKE '%'||'MAN'||'%';