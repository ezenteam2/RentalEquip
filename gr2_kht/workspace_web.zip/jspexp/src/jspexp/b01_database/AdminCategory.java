package jspexp.b01_database;

import java.sql.*;
import jspexp.z01_vo.*;
import java.util.*;

public class AdminCategory {

	private Connection con;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
public void setCon() throws SQLException{
	

	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	String info = "jdbc:oracle:thin:@192.168.4.90:1521:xe";
	con = DriverManager.getConnection(info, "scott", "tiger");


}	

	public ArrayList<AdminCategoryVO> getAdminCategory(){
		
		ArrayList<AdminCategoryVO> p4category = new ArrayList<AdminCategoryVO>();
		
		try {
			setCon();
			String sql = "SELECT * FROM P4ITEM_CATEGORY ORDER BY CATE_ORDER ";
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			AdminCategoryVO p4cate = null;
			
			
			while(rs.next()) {
				
				p4cate = new AdminCategoryVO(
						rs.getInt("cate_code"),
						rs.getDate("cate_date"),
						rs.getString("cate_title"),
						rs.getInt("cate_order"),
						rs.getString("cate_img")
						);
				p4category.add(p4cate);
			
			
		}
			
		rs.close();
		stmt.close();
		con.close();
		}	
			catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return p4category;
		
	}
	
	
	public void insertAdminCategory(AdminCategoryVO ins) {
		
		try {
			setCon();
			
			String sql = "INSERT INTO P4ITEM_CATEGORY VALUES (cate_code_seq.nextval, sysdate, ?, ?, ?) ";
			
			con.setAutoCommit(false);
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, ins.getCate_title());
			pstmt.setInt(2, ins.getCate_order());
			pstmt.setString(3, ins.getCate_img());
			
			System.out.println(sql);
			pstmt.executeUpdate();
			con.commit();
			
			pstmt.close();
			con.close();
			System.out.println("등록 성공!!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
